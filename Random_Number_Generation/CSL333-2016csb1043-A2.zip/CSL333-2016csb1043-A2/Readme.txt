---------------------------------------------------------------

Name :- Siddharth Nahar
Entry No :- 2016csb1043
Date :- 4/9/18
Purpose :- Unique Number Generated

---------------------------------------------------------------

Compiling Program:

User@Name:~/Dir javac Solution.java

*Compiles all classes in java files
---------------------------------------------------------------

Running code :

User@Name:~/Dir java Solution CL1 CL2 CL3 CL4* CL5* CL6*

CL1 : n as Nth Unique Number
CL2 : Number of Threads to Use
CL3 : real or unreal as Type of Device
CL4 : Optional but as Computational Delay
CL5 : Optional Boot Delay
CL6 : Optional Random Seed
-----------------------------------------------------------------

* For Optional arguments I have created Device Config file which stores

	ComputDelay = 3
	BootDelay = 250
	RandomSeed = 1

-------------------------------------------------------------------- 
