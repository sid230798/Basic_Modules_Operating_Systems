------------------------------------------------------

Name : Siddharth Nahar
Entry No : 2016csb1043
Date : 30/10/18
Purpose : 

	1. Readme for Memory Allocation module.
	2. Implemented as per specified in Pdf.

------------------------------------------------------

To Compile Code :-

Usr@Name:~$ gcc TEST_FILE memoryAllocation.c -o output

To Run:-

Usr@Name:~$ ./output

------------------------------------------------------

*Input TestFile as Input for Testing modules.

Sample Run :-

Usr@Name:~$ gcc memtest.c memoryAllocation.c -o output
Usr@Name:~$ ./output

-------------------------------------------------------
